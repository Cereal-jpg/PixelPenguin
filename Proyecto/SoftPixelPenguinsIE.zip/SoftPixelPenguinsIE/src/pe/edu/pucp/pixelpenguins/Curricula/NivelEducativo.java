
package pe.edu.pucp.PixelPenguins.Curricula;

public enum NivelEducativo {
    PRIMARIO,SECUNDARIO;
}
