package pe.edu.pucp.PixelPenguins.Curricula;

public enum DiaSemana {
    LUNES,MARTES,MIERCOLES,JUEVES,VIERNES;
}
