
package pe.edu.pucp.pixelpenguins.añoacademico;

public enum EstadoDePago {
    PENDIENTE,CANCELADO,ATRASADO,PAGO_PARCIAL,RECHAZADO;
}
