
package pe.edu.pucp.pixelpenguins.añoacademico;


public enum TipoDePago {
    BANCOS_ASOCIADOS,TRANSFERENCIA_BANCARIA;
}
