
package pe.edu.pucp.pixelpenguins.añoacademico;

public enum TipoDeComprobante {
    PENDIENTE,CANCELADO,ATRASADO,PAGO_PARCIAL,RECHAZADO;
}
